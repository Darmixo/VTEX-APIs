---
name: Feature request
about: 'Thanks for contributing. In case this request is not related to the OpenAPI
  schemas, we recommend posting it on the VTEX community: https://community.vtex.com/'
title: ''
labels: ''
assignees: ''

---

**Describe the solution you'd like**
A clear and concise description of what you want to happen.
