---
name: Custom issue template
about: 'Thanks for your contribution! Before contributing, please check if this issue
  is directly related to the OpenAPI 3.0 schemas in this repository. In case this
  issue concerns questions or bug reports about VTEX APIs or even VTEX, we recommend
  posting it on the VTEX community: https://community.vtex.com/'
title: ''
labels: ''
assignees: ''

---


